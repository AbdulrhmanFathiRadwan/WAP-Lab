

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MyServelt3
 */
@WebServlet("/MyServelt3")
public class MyServelt3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private static String[] questions = {
		        "3,1,4,1,5", //pi
		        "1,1,2,3,5", //fibonacci
		        "1,4,9,16,25", //squares
		        "2,3,5,7,11", //primes
		        "1,2,4,8,16" //power of 2
		    };

		    private static int[] answers = {9, 8, 36, 13, 32};
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServelt3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
	        HttpSession session = request.getSession();
	        
	        PrintWriter out = response.getWriter();

	        Integer index = (Integer) session.getAttribute("index");
//	        this.getServletContext().setAttribute("applicationState", "index");
	        if (index == null) {
	            index = 0;
	        } else {
	            index = index + 1;
	        }

	        session.setAttribute("index", index);

	        Integer score = (Integer) session.getAttribute("score");
//	        this.getServletContext().setAttribute("applicationState", "score");
	        
	        if (score == null) {
	            score = 0;
	        } else {
	            if (request.getParameter("input") != null) {
	                if (!request.getParameter("input").equals("")) {
	                    if (Integer.parseInt(request.getParameter("input")) == answers[index-1]) {
	                        score = score + 1;
	                    }
	                }
	            }
	        }
	        session.setAttribute("score", score);
	        Cookie c = new Cookie("cookieTemporaryStateIndex", "index");
	        response.addCookie(c);

	        c = new Cookie("cookieTemporaryStateScore", "score");
	        response.addCookie(c);
	        if (index == questions.length || index > questions.length) {
	            out.print("<html>"
	                    + "<head>"
	                    + "    <title>Number Quiz</title>"
	                    + "   <meta charset=\"UTF-8\">"
	                    + "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
	                    + " <link href=\"quiz.css\" type=\"text/css\" rel=\"stylesheet\"/>"
	                    + "</head>"
	                    + " <body>"
	                    + "   <div class=\"div1\">"
	                    + "       <form action=\"MyServelt3\" method=\"post\" name=\"form\">"
	                    + "         <h1 class=\"text\">The Number Quiz</h1>"
	                    + "       <div class=\"p\">"
	                    + "     <p>Your current score is " + score+".</p>"
	                    + "   <p>You have completed the Number Quiz with a score of " + score + " out of 5. </p>"
	                    + "</div>"
	                    + "</form>"
	                    + "</div>"
	                    + "</body>"
	                    + "</html>");
	            session.invalidate();
	        } else {
	            out.print("<html>"
	                    + "<head>"
	                    + "    <title>Number Quiz</title>"
	                    + "   <meta charset=\"UTF-8\">"
	                    + "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
	                    + " <link href=\"quiz.css\" type=\"text/css\" rel=\"stylesheet\"/>"
	                    + "</head>"
	                    + " <body>"
	                    + "   <div class=\"div1\">"
	                    + "       <form autocomplete=\"off\" action=\"MyServelt3\" method=\"post\" name=\"form\">"
	                    + "         <h1 class=\"text\">The Number Quiz</h1>"
	                    + "       <div class=\"p\">"
	                    + "     <p>Your score is " + score + "</p>"
	                    + "   <p>Guess the next number in the sequence</p>"
	                    + " <p>" + questions[index] + "</p>"
	                    + "<p>Your answer:"
	                    + "  <input type=\"text\" name=\"input\"/>"
	                    + "</p>"
	                    + "<p><button class=\"button\">Submit</button></p>"
	                    + "</div>"
	                    + "</form>"
	                    + "</div>"
	                    + "</body>"
	                    + "</html>");
	        }
	}

}
