

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServelt
 */
@WebServlet("/MyServelt")
public class MyServelt extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public MyServelt() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		

		
		
		PrintWriter out = response.getWriter();
		
		String add_num1String=request.getParameter("add_num1");
		String add_num2String=request.getParameter("add_num2");
	
		String mul_num1String=request.getParameter("mul_num1");
		String mul_num2String=request.getParameter("mul_num2");
		
		
		
	if(add_num1String.equals("") || add_num2String.equals("") ) {
			
		int mul_num1=Integer.parseInt(mul_num1String);
		int mul_num2=Integer.parseInt(mul_num2String);
		
		       int resultmul = mul_num1 * mul_num2;
		
			out.append(mul_num1 +"*"+mul_num2 +"="+resultmul);
			
			
		}
	else if(mul_num1String.equals("") || mul_num2String.equals("")) {
		
		int add_num1=Integer.parseInt(add_num1String);
		int add_num2=Integer.parseInt(add_num2String);
		
		       int resultadd = add_num1 + add_num2;
		
			out.append(add_num1 +"+"+add_num2 +"="+resultadd);
			
				
	}
		else {
				
			int mul_num1=Integer.parseInt(mul_num1String);
			int mul_num2=Integer.parseInt(mul_num2String);
			
			int add_num1=Integer.parseInt(add_num1String);
			int add_num2=Integer.parseInt(add_num2String);
			
			  int resultmul = mul_num1 * mul_num2;
			  int resultadd = add_num1 + add_num2;
			
				out.append("<div>"+add_num1 +"+"+add_num2 +"="+resultadd +"</div>");
			
				out.append(mul_num1 +"*"+mul_num2 +"="+resultmul);	
		}
	

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
