

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServelt2
 */
@WebServlet("/MyServelt2")
public class MyServelt2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServelt2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		
		
		PrintWriter out = response.getWriter();
		
		String add_num1String=request.getParameter("add_num1");
		String add_num2String=request.getParameter("add_num2");
	
		String mul_num1String=request.getParameter("mul_num1");
		String mul_num2String=request.getParameter("mul_num2");
		
	
		
		out.append("<!DOCTYPE html>\r\n" + 
				"<html lang=\"en\">\r\n" + 
				"<head>\r\n" + 
				"    <meta charset=\"UTF-8\">\r\n" + 
				"    <title>CALC2</title>\r\n" + 
				"    <link href=\"../resources/style.css\" rel=\"stylesheet\">\r\n" + 
				"</head>\r\n" + 
				"<style>" +
			"	input[type=text], select {" +
				"  width: 100%;" +
				 " padding: 12px 20px;" +
				 " margin: 8px 0;" +
				"  display: inline-block;" +
				"  border: 1px solid #ccc;" +
				 " border-radius: 4px;" +
				"  box-sizing: border-box;" +
				"}" +

				"input[type=submit] {" +
				 " width: 100%;" +
				"  background-color: #4CAF50;" +
				"  color: white;" +
				" padding: 14px 20px;" +
				 " margin: 8px 0;" +
				 " border: none;" +
				"  border-radius: 4px;" +
				 " cursor: pointer;" +
				"}" +

				"input[type=submit]:hover {" +
				"  background-color: #45a049;" +
				"}" +

				"div {" +
				"  border-radius: 5px;" +
				"  background-color: #f2f2f2;" +
				"  padding: 20px;" +
				"}" +
				"</style>" +
				"<body>\r\n" + 
				"<fieldset>\r\n" + 
				"    <legend>Calculator</legend>\r\n" + 
				"    <form action=\"Servlet\" method=\"get\">\r\n" + 
				"\r\n" + 
				"        <div class=\"input_line\">");
		
		
		
	if(add_num1String.equals("") || add_num2String.equals("") ) {
			
		int mul_num1=Integer.parseInt(mul_num1String);
		int mul_num2=Integer.parseInt(mul_num2String);
		
		       int resultmul = mul_num1 * mul_num2;
		
			
			out.append("<div class=\"input_line\">" + " <input type=\"number\"  name=\"add_num1\" >" + "+" +
					" <input type=\"number\"  name=\"add_num2\" >"+ "=" + "<input type=\"text\">" + "</div>" + "<br>");
			
			out.append("<div class=\"input_line\">" + "<input type=\"number\" name=\"mul_num1\" value="+mul_num1+">" + "*" +
					"<input type=\"number\" name=\"mul_num2\" value="+mul_num2+">" + "=" + "<input type=\"text\" value="+resultmul+" >"
					
					);
			
			
		}
	else if(mul_num1String.equals("") || mul_num2String.equals("")) {
		
		int add_num1=Integer.parseInt(add_num1String);
		int add_num2=Integer.parseInt(add_num2String);
		
		       int resultadd = add_num1 + add_num2;
		
			
			
			out.append("<input type=\"number\"  name=\"add_num1\" value = "+add_num1+">"+ "+" + "<input type=\"number\" name=\"add_num2\" value="+add_num2+">" +
					
						"=" + "<input type=\"text\" value="+resultadd+">" + "</div> "
					);
			out.append("<input type=\"number\" name=\"mul_num1\">" + "*"  + "<input type=\"number\" name=\"mul_num2\">" +"="  + "<input type=\"text\">" );
			
				
	}
		else {
				
			int mul_num1=Integer.parseInt(mul_num1String);
			int mul_num2=Integer.parseInt(mul_num2String);
			
			int add_num1=Integer.parseInt(add_num1String);
			int add_num2=Integer.parseInt(add_num2String);
			
			  int resultmul = mul_num1 * mul_num2;
			  int resultadd = add_num1 + add_num2;
			
			
				
				out.append("<input type=\"number\"  name=\"add_num1\" value = "+add_num1+">"+ "+" + "<input type=\"number\" name=\"add_num2\" value="+add_num2+">" +
						
						"=" + "<input type=\"text\" value="+resultadd+">" + "</div>"
					);
				out.append("<div class=\"input_line\">" + "<input type=\"number\" name=\"mul_num1\" value="+mul_num1+">" + "*" +
						"<input type=\"number\" name=\"mul_num2\" value="+mul_num2+">" + "=" + "<input type=\"text\" value="+resultmul+" >"
						
						);
				
				
		}
	

		
			out.append("        <div class=\"input_line\">\r\n" + 
					"            <input class=\"input-submit\" type=\"submit\" value=\"Submit\">\r\n" + 
					"        </div>\r\n" + 
					"    </form>\r\n" + 
					"</fieldset>\r\n" + 
					"</body>\r\n" + 
					"</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
